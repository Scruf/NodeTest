var myModule = require('./my-module.js');

console.log('text from module:', myModule.myText);