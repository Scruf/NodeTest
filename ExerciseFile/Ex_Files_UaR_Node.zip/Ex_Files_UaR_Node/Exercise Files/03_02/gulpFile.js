var gulp = require('gulp');

gulp.task('default', function() {
    console.log('hello from gulp');
});